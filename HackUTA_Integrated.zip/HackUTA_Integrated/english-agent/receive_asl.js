// Run in a second terminal to see incoming ASL captions.
const { receiveAsl } = require('./shared_api');
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
async function main() {
  let after = 0;
  console.log('Waiting for ASL translations... (Ctrl+C to stop)');
  while (true) {
    try {
      for (const message of await receiveAsl(after)) {
        console.log('ASL caption:', message.clean_text);
        after = message.id;
      }
    } catch (error) {
      console.error('Shared API:', error.message);
    }
    await sleep(1000);
  }
}
main();
