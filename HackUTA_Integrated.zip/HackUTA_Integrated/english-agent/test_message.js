const { sendTranslation } = require('./shared_api');
const text = process.argv.slice(2).join(' ') || 'Yes, how can I help you?';
sendTranslation({ source: 'english', original_text: text, clean_text: text, intent: 'other' })
  .then(result => console.log('Sent:', result.message))
  .catch(error => { console.error(error.message); process.exitCode = 1; });
