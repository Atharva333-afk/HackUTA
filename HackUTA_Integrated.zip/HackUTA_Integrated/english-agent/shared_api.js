// Same JSON contract as the Python agent.
require('dotenv').config({ path: require('path').join(__dirname, '.env.local') });
const base = () => (process.env.SHARED_API_URL || 'http://127.0.0.1:8000').replace(/\/$/, '');
async function request(path, options = {}) {
  const token = process.env.SHARED_API_TOKEN;
  if (!token) throw new Error('Set SHARED_API_TOKEN in .env.local');
  const response = await fetch(`${base()}${path}`, {
    ...options,
    headers: { 'Content-Type': 'application/json', 'X-API-Token': token },
    signal: AbortSignal.timeout(5000),
  });
  if (!response.ok) throw new Error(`Shared API HTTP ${response.status}`);
  return response.json();
}
async function sendTranslation(message) {
  return request('/messages', { method: 'POST', body: JSON.stringify(message) });
}
async function receiveAsl(after = 0) {
  return request(`/messages/asl?after=${encodeURIComponent(after)}`);
}
module.exports = { sendTranslation, receiveAsl };
